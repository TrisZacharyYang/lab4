#include "threads/thread.h"
#include "threads/synch.h"
#include <stdio.h>


// More of my description is also in the document

static struct semaphore done_sema; // To let threads finish
static int threads_left; // Keep track of how many threads are left

// Will be treated as threads
void worker(void *aux) {
    const char *name = aux;

    for (int i = 0; i < 5; i++) {
        msg("[%s's Windows] CPU munching, priority = %d", name, thread_get_priority());
        thread_yield();
    }

    // let test_cpu_io_brawl know 
    threads_left--;
    if (threads_left == 0)
        sema_up(&done_sema);
}

void test_cpu_brawl(void) {
    msg("=== Professors Showdown ===");
    msg("Let professors race 😎");

    //Initialize done_sema
    sema_init(&done_sema, 0);
    threads_left = 4;

    thread_create("Sven", 18, worker, "Sven");
    thread_create("Bob", 7, worker, "Bob");
    thread_create("Theresa", 7, worker, "Theresa");
    thread_create("Kerri", 3, worker, "Kerri");

    // Wait for all threads to finish
    sema_down(&done_sema);

    msg("All professors finished!");
}

