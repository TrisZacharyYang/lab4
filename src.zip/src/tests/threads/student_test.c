#include <stdio.h>
#include "threads/thread.h"
#include "threads/synch.h"
#include "threads/malloc.h"
#include "devices/timer.h"

// AUTHORS: THU and ARLO
// Made with love by Bard CS students
// Please do NOT use this for future system courses

// Short jobs
static void short_job(void *aux UNUSED) {
  msg("[SHORT] start (should finish before demotion)\n");
  timer_sleep(1); // Less than 1 quantum
  msg("[SHORT] end\n");
}

// Long jobs
static void long_job(void *aux UNUSED) {
  msg("[LONG] start (should fall through queues)\n");
  // burn CPU long enough to exceed several quantums
  for (int i = 0; i < 120000000; i++);
  msg("[LONG] end\n");
}

// Round-robin test 
static void rr_job(void *aux) {
  int id = (int) aux;
  for (int i = 0; i < 3; i++) {
    msg("[RR %d] running (iteration %d)\n", id, i);
    timer_sleep(1);   // enough to switch but not demote
  }
}

// jobs falling together when quantum is small
static void many_job(void *aux) {
  int id = (int) aux;
  for (int i = 0; i < 50000000; i++);  // Causes demotion
  msg("[MANY %d] done\n", id);
}

void test_student_test(void) {
  msg("=== MLFQS Test Start ===\n");

  // short_job
  thread_create("short", PRI_DEFAULT, short_job, NULL);

  // long_job
  thread_create("long", PRI_DEFAULT, long_job, NULL);

  // rr_job
  thread_create("rr1", PRI_DEFAULT, rr_job, 1);
  thread_create("rr2", PRI_DEFAULT, rr_job, 2);

  // many_job
  for (int i = 0; i < 3; i++){
    thread_create("many", PRI_DEFAULT, many_job, i);
  }
  
  // Wait for boost.
  msg("[TEST] Waiting for boost...\n");
  timer_sleep(60);     // assumes boostInterval = 50 ticks
  msg("[TEST] Boost should occurr.\n");

  timer_sleep(30);     // allow all threads to finish
  msg("=== End ===\n");
}

